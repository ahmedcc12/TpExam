﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TpExam
{
    class FlyoutItem
    {
        public String Title { get; set; }
        public String IconSource { get; set; }
        public Type TargetPage { get; set; }
    }
}
