﻿using Xamarin.Forms.Xaml;

namespace TpExam.Styles
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BoxViewStyles
    {
        public BoxViewStyles()
        {
            this.InitializeComponent();
        }
    }
}