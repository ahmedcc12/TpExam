﻿using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

namespace TpExam.Styles
{
    [Preserve(AllMembers = true)]
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ComboBoxStyles
    {
        public ComboBoxStyles()
        {
            this.InitializeComponent();
        }
    }
}