﻿using Xamarin.Forms.Xaml;

namespace TpExam.Styles
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AvatarViewStyles
    {
        public AvatarViewStyles()
        {
            this.InitializeComponent();
        }
    }
}